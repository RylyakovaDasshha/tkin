import tkinter as tk
 
window = tk.Tk()
label = tk.Label(text="Python рулит!")
label.pack()
 
window.mainloop()